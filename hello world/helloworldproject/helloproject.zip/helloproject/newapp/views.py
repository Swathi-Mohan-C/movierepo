from django.contrib.auth.models import User
from django.shortcuts import render

# Create your views here.
def register(request):
    if request.method=='post':
        userName = request.POST('userName')
        FirstName = request.POST('FirstName')
        LastName = request.POST('LastName')
        email = request.POST('email')
        password = request.POST('Password')
        password1 = request.POST('Password1')
        if password==password1:
            user=User.objects.create_user(userName=userName,FirstName=FirstName,LastName=LastName,email=email)
            user.save()
            print("user created")
        else:
            print("not matched")

    return render(request,"register.html")